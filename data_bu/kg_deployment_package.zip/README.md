# Knowledge Graph Deployment Package

Generated: 2025-12-03T09:26:29.799007

## Contents

1. **memgraph_export.cypher** - Cypher queries to recreate the knowledge graph
2. **custom_relations_vdb/** - ChromaDB vector database with relation types
3. **property_vdb/** - ChromaDB vector database with property value embeddings

## Deployment Instructions

### 1. Import Memgraph Data

```bash
# Option A: Using mgconsole (Memgraph CLI)
cat memgraph_export.cypher | mgconsole --host <host> --port <port>

# Option B: Using Python
from neo4j import GraphDatabase

driver = GraphDatabase.driver("bolt://<host>:<port>", auth=("<user>", "<password>"))
with driver.session() as session:
    with open("memgraph_export.cypher", "r") as f:
        queries = f.read().split(';')
        for query in queries:
            if query.strip():
                session.run(query)
```

### 2. Deploy Vector Databases

Copy the VDB directories to your application server:

```bash
# Copy to your application directory
cp -r custom_relations_vdb /path/to/app/
cp -r property_vdb /path/to/app/
```

Update your application configuration to point to these paths.

### 3. Verify Deployment

```cypher
# Check node count
MATCH (n) RETURN count(n);

# Check relationship count
MATCH ()-[r]->() RETURN count(r);

# Sample query
MATCH (p:Clothing)-[:HAS_BRAND]->(b)
RETURN p.prod_name, b.name
LIMIT 10;
```

## Graph Schema

### Node Labels
- Category-based labels (e.g., `:Clothing`, `:Electronics`, `:Furniture`)
  - Properties: `name` (product_id), `prod_name`

- `:manufacturer` - Brand/manufacturer nodes
  - Properties: `name`

- `:colour` - Color attribute nodes
  - Properties: `name`

- `:seller` - Store/seller nodes
  - Properties: `name`

- `:property` - Generic property values (from descriptions)
  - Properties: `name`

### Relationships
- `HAS_BRAND` - Product to manufacturer
- `HAS_COLOR` - Product to colour
- `SOLD_BY` - Product to seller
- Dynamic relations from descriptions (e.g., `HAS_PROCESSOR`, `HAS_MATERIAL`, etc.)

## Vector Databases

### custom_relations_vdb
- Contains embeddings of relation types
- Used for relation standardization during extraction
- Model: sentence-transformers/all-MiniLM-L6-v2

### property_vdb
- Contains embeddings of property values (format: "type:value")
- Examples: "color:red", "brand:LoomNest", "store:Aara Boutique"
- Used for curator algorithm and similarity search
- Model: sentence-transformers/all-MiniLM-L6-v2

## Support

For issues or questions, contact the data engineering team.
